# Chrome Storage stores settings

# Pomodoro
* Developed in `/developing/pomodoro/`
* Bundled into `/src/do_not_edit/*`

